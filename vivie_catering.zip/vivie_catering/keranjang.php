<!DOCTYPE html>
<html lang="en">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<?php
session_start();
if (!isset($_SESSION['pelanggan'])) {
    echo "<script>alert('Anda harus login terlebih dahulu.')</script>";
    echo "<script>location='login.php'</script>";
    session_destroy();
}
include 'koneksi.php';
?>
<?php
$jml = '0';
if (isset($_SESSION['pelanggan'])) {
    if (isset($_SESSION['keranjang'])) {
        foreach ($_SESSION['keranjang'] as $id_produk => $jumlah) :
            $jml += $jumlah;
        endforeach;
    } else {
        $jml = '0';
    }
}
?>
<!-- jika keranjang Kosong -->
<?php
if(empty($_SESSION['keranjang']) OR !isset($_SESSION['keranjang']))
{
    echo "<script>alert('Keranjang kosong, silahkan belanja dulu');</script>";
    echo "<script>location='products.php';</script>";
}
?>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap" rel="stylesheet">

    <title>Vivie Catering</title>

    <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">

    <link rel="stylesheet" type="text/css" href="assets/css/font-awesome.css">

    <link rel="stylesheet" href="assets/css/style.css">

</head>

<body>

    <!-- ***** Preloader Start ***** -->
    <div id="js-preloader" class="js-preloader">
        <div class="preloader-inner">
            <span class="dot"></span>
            <div class="dots">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>
    </div>
    <!-- ***** Preloader End ***** -->


    <!-- ***** Header Area Start ***** -->
    <header class="header-area header-sticky">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <nav class="main-nav">
                        <!-- ***** Logo Start ***** -->
                        <a href="index.php" class="logo">Vivie <em> Catering</em></a>
                        <!-- ***** Logo End ***** -->
                        <!-- ***** Menu Start ***** -->
                        <ul class="nav">
                            <li><a href="index.php" class="active">Beranda</a></li>
                            <li><a href="products.php">Produk</a></li>
                            <li><a href="checkout.php">Checkout</a></li>
                            <li><a href="keranjang.php">Keranjang</a></li>
                            <li><a href="riwayat.php">Riwayat</a></li>
                            <li><a href="about.php">Tentang</a></li>
                            <!-- Sudah login -->
                            <?php if (isset($_SESSION['pelanggan'])) : ?>
                                <strong><a href="logout.php" class="btn ml-3 text-danger">Logout</a></strong>
                            <?php else : ?>
                                <!-- Sudah login -->
                                <strong><a href="logout.php"  style="color:#000000;" class="btn ml-3 text-warning">Login</a></strong>
                            <?php endif ?>


                        </ul>
                        <a class='menu-trigger'>
                            <span>Menu</span>
                        </a>
                        <!-- ***** Menu End ***** -->
                    </nav>
                </div>
            </div>
        </div>
    </header>
    <!-- ***** Header Area End ***** -->

    <!-- ***** Call to Action Start ***** -->
    <section class="section section-bg" id="call-to-action" style="background-image: url(assets/images/banner-image-1-1920x500.jpg)">
        <div class="container">
            <div class="row">
                <div class="col-lg-10 offset-lg-1">
                    <div class="cta-content">
                        <br>
                        <br>
                        <h2>Halaman <em>Keranjang</em></h2>
                        <p>Pelanggan dapat memilih atau mengecek kembali produk yang akan di checkout</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ***** Call to Action End ***** -->

    <!-- ***** Fleet Starts ***** -->
    <section class="section" id="trainers">
        <div class="konten">
            <div class="container-fluid">
                <div class="card-body col-md-9 mx-auto">
                    <h1 class="font-weight mb-4">Keranjang Belanja</h1>
                    <div class="table-responsive">
                        <form method="POST" action="hapuskeranjang.php" id="form-delete">
                        <table class="table table-bordered text-black bg-white thead-light" width="100%" cellspacing="0">
                            <thead class="thead-dark">
                                <tr>
                                    <th><center>No</center></th>
                                    <th><center>Nama</center></th>
                                    <th><center>Harga</center></th>
                                    <th><center>Jumlah</center></th>
                                    <th><center>Total</center></th>
                                    <th><center><center><input type="checkbox" id="check-all"></center></center></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $no = 1;
                                $total = 0;
                                if ($jml > 0) {
                                    foreach ($_SESSION['keranjang'] as $id_produk => $jumlah) :
                                        //menampilkan produk yang sedang diperulangkan berdasarkan id produk
                                        $ambil = $koneksi->query("SELECT * FROM produk WHERE id_produk = '$id_produk'");
                                        $data = $ambil->fetch_assoc();
                                        //penjumlahan sub total
                                        $subtotal = $data['harga_produk'] * $jumlah; ?>
                                        <tr>
                                            <td><?= $no ?></td>
                                            <td><?= $data['nama_produk'] ?></td>
                                            <td>Rp. <?= number_format($data['harga_produk']) ?></td>
                                            <td><?= $jumlah ?></td>
                                            <td>Rp. <?= number_format($subtotal)  ?></td>
                                            <td>
                                                <center><input type='checkbox' class='check-item' name='id_produk[]' value="<?= $data['id_produk']?>"></center>
                                            </td>
                                        </tr>
                                    <?php $no++;
                                        $total += $subtotal;
                                    endforeach; ?><tr>
                                        <td colspan='4'>Total Belanja</td>
                                        <td>Rp. <?= number_format($total) ?></td>
                                        <td>
                                            <center><button type="button" id="btn-delete" class="badge badge-danger">Hapus</button></center>
                                        </td>

                                    </tr>

                                <?php } else { ?>
                                    <tr>
                                        <td colspan="6">Kosong</td>


                                    </tr>
                                <?php } ?>
                            </tbody>

                        </table>
                        </form>
                    </div>
                    <a href="products.php" class="btn btn-light">Lanjut Belanja</a>
                    <?php
                    if ($jml == 0) { ?>
                        <button class="btn btn-primary disabled">Checkout</button>
                    <?php } else { ?>
                        <a href="checkout.php" class="btn btn-primary">Checkout</a>
                    <?php }
                    ?>

                </div>



            </div>
        </div>
    </section>
    <!-- ***** Fleet Ends ***** -->
    
    <script>
        $(document).ready(function(){ // Ketika halaman sudah siap (sudah selesai di load)
        $("#check-all").click(function(){ // Ketika user men-cek checkbox all
        if($(this).is(":checked")) // Jika checkbox all diceklis
            $(".check-item").prop("checked", true); // ceklis semua checkbox siswa dengan class "check-item"
        else // Jika checkbox all tidak diceklis
            $(".check-item").prop("checked", false); // un-ceklis semua checkbox siswa dengan class "check-item"
        });
    
        $("#btn-delete").click(function(){ // Ketika user mengklik tombol delete
        var confirm = window.confirm("Apakah Anda yakin ingin menghapus data-data ini?"); // Buat sebuah alert konfirmasi
      
        if(confirm) // Jika user mengklik tombol "Ok"
            $("#form-delete").submit(); // Submit form
    });
  });
  </script>

    <!-- ***** Footer Start ***** -->
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <p>
                        Copyright © 2022 Nopal
                </div>
            </div>
        </div>
    </footer>

    <!-- jQuery -->
    <script src="assets/js/jquery-2.1.0.min.js"></script>

    <!-- Bootstrap -->
    <script src="assets/js/popper.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>

    <!-- Plugins -->
    <script src="assets/js/scrollreveal.min.js"></script>
    <script src="assets/js/waypoints.min.js"></script>
    <script src="assets/js/jquery.counterup.min.js"></script>
    <script src="assets/js/imgfix.min.js"></script>
    <script src="assets/js/mixitup.js"></script>
    <script src="assets/js/accordions.js"></script>

    <!-- Global Init -->
    <script src="assets/js/custom.js"></script>

    <!-- Script untuk memanggil checkbox hapus keranjang -->
    
</body>

</html>