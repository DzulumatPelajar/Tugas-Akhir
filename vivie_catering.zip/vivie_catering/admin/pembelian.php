<h1>Pembelian</h1>
<!-- table -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Data Pembelian</h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Pelanggan</th>
                        <th>Tanggal</th>
                        <th>Total</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $no = 1;
                    $ambil = $koneksi->query("SELECT * FROM pembelian JOIN pelanggan ON pembelian.
                    id_pelanggan = pelanggan.id_pelanggan");
                    while ($data = $ambil->fetch_assoc()) {
                    ?>
                        <tr>
                            <td><?= $no ?></td>
                            <td><?= $data['nama'] ?></td>
                            <td><?= $data['tanggal_pembelian'] ?></td>
                            <td>Rp. <?= number_format($data['total_harga'])  ?></td>
                            <td><?= $data['status_pembayaran'] ?></td>
                            <td>
                                <a data-toggle="modal" id="detail" data-id="<?= $data['id_pembelian'] ?>" class="open-modal btn btn-info" data-target="#detailModal">Detail</a>
                                <?php if ($data['status_pembayaran'] !== 'pending') { ?>
                                    <a href="index.php?halaman=pembayaran&id=<?php echo $data['id_pembelian'] ?>" class="btn btn-success">Lihat Pembayaran</a>
                                <?php } ?>
                            </td>
                        </tr>
                    <?php $no++;
                    } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<!-- Modal -->
<div class="modal fade" id="detailModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="detailModalLabel">Detail Pembelian</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-success" data-dismiss="modal">Oke</button>
            </div>
        </div>
    </div>
</div>