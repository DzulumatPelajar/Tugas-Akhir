<h1>Pembayaran</h1>
<?php
$id_pembelian = $_GET['id'];

$ambil = $koneksi->query("SELECT * FROM pembayaran JOIN pembelian ON 
pembayaran.id_pembelian = pembelian.id_pembelian WHERE pembayaran.id_pembelian ='$id_pembelian'");

$data = $ambil->fetch_assoc();
if (empty($data)) {
    echo "<script>alert('Tidak ada data pembayaran.')</script>";
    echo "<script>location='index.php?halaman=pembelian'</script>";
}

?>
<div class="card-body shadow bg-white mb-4">

    <div class="row">
        <div class="col-md-6">
            <table class="table">
                <tr>
                    <th>Nama Penyetor</th>
                    <td><?= $data['nama'] ?></td>
                </tr>
                <tr>
                    <th>Bank</th>
                    <td><?= $data['bank'] ?></td>
                </tr>
                <tr>
                    <th>Tanggal</th>
                    <td><?= $data['tanggal'] ?></td>
                </tr>
                <tr>
                    <th>Jumlah Tagihan</th>
                    <td>Rp. <?= number_format($data['total_harga'])  ?></td>
                </tr>
            </table>
        </div>
        <div class="col-md-6">
            <img src="../assets/images/bukti/<?= $data['bukti'] ?>" alt="" class="img-responsive" height="250px">
        </div>

    </div>

    <form action="" method="POST" class="mt-3">
        <div class="row">
            <div class="col-md-6">
                <div class="form-group">
                    <label for="" class="text-boldfont-weight-bold">Resi</label>
                    <input type="number" name='resi' class='form-control'>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label for="" class="text-boldfont-weight-bold">Status</label>
                    <select name='status' class='form-control'>
                        <option value="sudah kirim bukti">-- Pilih Status--</option>
                        <option value="lunas">Lunas</option>
                        <option value="batal">Batal</option>
                        <option value="barang dikirim">Barang dikirim</option>
                    </select>
                </div>
            </div>
        </div>
        <button name="proses" type="submit" class="btn btn-primary">Proses</button>

    </form>
    <?php
    if (isset($_POST['proses'])) {
        $resi = $_POST['resi'];
        $status = $_POST['status'];
        $koneksi->query("UPDATE pembelian SET resi = '$resi', status_pembayaran='$status' WHERE id_pembelian = '$id_pembelian'");
        echo "<script>alert('data pembelian terupdate')</script>";
        echo "<script>location='index.php?halaman=pembelian'</script>";
    }
    ?>
</div>