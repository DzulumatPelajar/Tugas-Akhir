<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Export Laporan Pembelian</title>
</head>
<body>
    <?php
    header('content-Type: application/vnd-ms-excel');
    header('content-Disposition: attachment; filename=Laporan Pembelian.xls');
    ?>
    <border >
    <table border='1' class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Pelanggan</th>
                        <th>Tanggal</th>
                        <th>Jumlah</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        include_once('../koneksi.php');
                        $tglm = '-';
                        $tgls = '-';
                        $semuadata = array();
                        
                            $tglm = $_GET['tglm'];
                            $tgls = $_GET['tgls'];
                            $ambil = $koneksi->query("SELECT * FROM pembelian JOIN pelanggan ON pembelian.
                            id_pelanggan = pelanggan.id_pelanggan 
                            WHERE ((tanggal_pembelian BETWEEN '$tglm' AND '$tgls') AND status_pembayaran != 'pending')");

                            while ($pecah = $ambil->fetch_assoc()) {
                                $semuadata[] = $pecah;
                            }
                            // echo "<pre>";
                            // print_r($semuadata);
                            // echo "</pre>";
                        
                    ?>
                    <?php
                    $no = 1;
                    foreach ($semuadata as $key => $data) :
                    ?>
                        <tr>
                            <td><?= $no ?></td>
                            <td><?= $data['nama'] ?></td>
                            <td><?= $data['tanggal_pembelian'] ?></td>
                            <td>Rp. <?= number_format($data['total_harga'])  ?></td>
                            <td><?= $data['status_pembayaran'] ?></td>
                        </tr>
                    <?php $no++;
                    endforeach; ?>
                </tbody>
            </table>
        </border>
</body>
</html>