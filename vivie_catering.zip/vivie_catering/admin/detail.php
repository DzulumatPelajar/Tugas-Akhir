<?php
include '../koneksi.php';
$id = json_encode($_POST['id']);
$ambil = $koneksi->query("SELECT * FROM pembelian JOIN pelanggan
    ON pembelian.id_pelanggan = pelanggan.id_pelanggan
    WHERE pembelian.id_pembelian= $id ");
$detail = $ambil->fetch_assoc();
?>
<!-- menampilkan detail -->
<strong><?= $detail['nama'] ?></strong><br>
<p>
    <?= $detail['telepon'] ?><br>
    <?= $detail['email'] ?>
</p>
<p>
    Tanggal Pembelian = <?= $detail['tanggal_pembelian'] ?><br>
    Total harga = <?= $detail['total_harga'] ?>
</p>
<!-- Menampilkan tabel detail produk -->
<div class="table-responsive">
    <table class="table table-bordered" id="dataTable">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Produk</th>
                <th>Harga</th>
                <th>Jumlah</th>
                <th>Subtotal</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $no = 1;
            $data = $koneksi->query("SELECT * FROM pembelian_produk JOIN produk ON
                pembelian_produk.id_produk= produk.id_produk
                WHERE pembelian_produk.id_pembelian= $id");
            while ($pecah = $data->fetch_assoc()) { ?>
                <tr>
                    <td><?= $no ?></td>
                    <td><?= $pecah['nama_produk'] ?></td>
                    <td><?= $pecah['harga_produk'] ?></td>
                    <td><?= $pecah['jumlah'] ?></td>
                    <td><?= $pecah['harga_produk'] ?></td>
                </tr>
            <?php
                $no++;
            } ?>
        </tbody>
    </table>
    <div>