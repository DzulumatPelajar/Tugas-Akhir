<h1>Produk</h1>

<!-- table -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Data Produk</h6>
    </div>
    <div class="card-body">

        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <a href="#" class="btn btn-primary mb-3" data-toggle="modal" data-target="#tambahModal">Tambah Produk</a>
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama</th>
                        <th>harga</th>
                        <th>Berat</th>
                        <th>Foto</th>
                        <th>Deskripsi</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $no = 1;
                    $ambil = $koneksi->query("SELECT * FROM produk");
                    while ($data = $ambil->fetch_assoc()) {
                    ?>
                        <tr>
                            <td><?= $no ?></td>
                            <td><?= $data['nama_produk'] ?></td>
                            <td><?= $data['harga_produk'] ?></td>
                            <td><?= $data['berat'] ?></td>
                            <td>
                                <img src="../assets/images/produk/<?= $data['foto_produk'] ?>" width="100">
                            </td>
                            <td><?= $data['deskripsi_produk'] ?></td>
                            <td>
                                <a href="#" class="edit-modal badge badge-success" data-toggle="modal" data-target="#editModal" data-id="<?= $data['id_produk'] ?>" data-nama='<?= $data['nama_produk'] ?>' data-harga='<?= $data['harga_produk'] ?>' data-berat='<?= $data['berat'] ?>' data-foto='<?= $data['foto_produk'] ?>' data-deskripsi='<?= $data['deskripsi_produk'] ?>'>Edit</a>
                                <a href="#" class="hapus-modal badge badge-danger" data-toggle="modal" data-target="#hapusModal" data-id="<?= $data['id_produk'] ?>">Hapus</a>
                            </td>
                        </tr>
                    <?php $no++;
                    } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<!-- Modal Tambah Produk-->
<div class="modal fade" id="tambahModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="detailModalLabel">Tambah Produk</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form method="POST" enctype="multipart/form-data">
                <div class="modal-body">

                    <div class="form-group">
                        <label>Nama</label>
                        <input type="text" class="form-control" name="nama" required>
                    </div>
                    <div class="form-group">
                        <label>Harga</label>
                        <input type="number" class="form-control" name="harga" required>
                    </div>
                    <div class="form-group">
                        <label>Berat</label>
                        <input type="number" class="form-control" name="berat" required>
                    </div>
                    <div class="form-group">
                        <label>Deskripsi</label>
                        <textarea class="form-control" name="deskripsi" required></textarea>
                    </div>
                    <div class="form-group">
                        <label>Foto</label>
                        <input type="file" class="form-control" name="foto">
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <input type="submit" class="btn btn-success" name='save' value="Tambah">
                </div>
            </form>
            <?php
            if (isset($_POST['save'])) {
                $nama = $_FILES['foto']['name'];
                $lokasi = $_FILES['foto']['tmp_name'];
                move_uploaded_file($lokasi, "../assets/images/produk/" . $nama);
                $koneksi->query("INSERT INTO produk
                (nama_produk, harga_produk, berat, foto_produk, deskripsi_produk)VALUE
                ('$_POST[nama]', '$_POST[harga]', '$_POST[berat]', '$nama', '$_POST[deskripsi]')");

                echo "<div class='alert alert-success' role='alert'>Berhasil Ditambah</div>";
                echo "<meta http-equiv= 'refresh' content='1;url=index.php?halaman=produk'>";
            }
            ?>
        </div>
    </div>
</div>
<!-- Hapus Modal-->
<div class="modal fade" id="hapusModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Hapus Data Produk</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <form action="hapus.php" method="POST">
                <div class="hapusbody-modal modal-body">Apakah kamu yakin ingin menghapusnya?
                    <input type="hidden" name='id_prod' id='id_prod'>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary" name="hapusdata">Hapus</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Edit-->
<div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="detailModalLabel">Edit Produk</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form method="POST" enctype="multipart/form-data">
                <div class="modal-body">
                    <input type="hidden" class="form-control" name="id" id='id' required>
                    <div class="form-group">
                        <label>Nama</label>
                        <input type="text" class="form-control" name="nama" id='nm' required>
                    </div>
                    <div class="form-group">
                        <label>Harga</label>
                        <input type="number" class="form-control" name="harga" id='hr' required>
                    </div>
                    <div class="form-group">
                        <label>Berat</label>
                        <input type="number" class="form-control" name="berat" id='br' required>
                    </div>
                    <div class="form-group">
                        <label>Deskripsi</label>
                        <textarea class="form-control" name="deskripsi" id='ds' required></textarea>
                    </div>
                    <div class="form-group">
                        <label>Ganti Foto</label>
                        <input type="hidden" class="form-control" name="fotolama" id='ftlm'>
                        <input type="file" class="form-control" name="foto">
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <input type="submit" class="btn btn-success" name='edit' value="Edit">
                </div>
            </form>
            <?php
            if (isset($_POST['edit'])) {
                $namafoto = $_FILES['foto']['name'];
                $lokasi = $_FILES['foto']['tmp_name'];
                // jika foto dirubah
                // !empty = tidak kosong
                if (!empty($lokasi)) {
                    move_uploaded_file($lokasi, "../assets/images/produk/" . $namafoto);
                    $koneksi->query("UPDATE produk SET nama_produk='$_POST[nama]', 
                harga_produk = '$_POST[harga]', berat = '$_POST[berat]', foto_produk = '$namafoto', 
                deskripsi_produk = '$_POST[deskripsi]' WHERE id_produk = '$_POST[id]'");
                } else {
                    $koneksi->query("UPDATE produk SET nama_produk='$_POST[nama]', 
                harga_produk = '$_POST[harga]', berat = '$_POST[berat]',
                deskripsi_produk = '$_POST[deskripsi]' WHERE id_produk = '$_POST[id]'");
                }


                echo "<div class='alert alert-success' role='alert'>Berhasil Diubah</div>";
                echo "<meta http-equiv= 'refresh' content='1;url=index.php?halaman=produk'>";
            }
            ?>
        </div>
    </div>
</div>