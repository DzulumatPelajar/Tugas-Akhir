<?php
session_start();
include '../koneksi.php';
if (!isset($_SESSION['admin'])) {
?><script>
        alert('Anda harus login dahulu');
        location = '../login.php';
    </script>
<?php
    exit();
}
?>

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Halaman Admin</title>
    <link href='../img/Nop.jpg' rel='shortcut icon'>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

    <!-- Custom styles for this page -->
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

</head>

<br>
<br>
<!-- table -->
<?php
$tglm = '-';
$tgls = '-';
$semuadata = array();
if (isset($_POST['cari'])) {
    $tglm = $_POST['tglm'];
    $tgls = $_POST['tgls'];
    $ambil = $koneksi->query("SELECT * FROM pembelian JOIN pelanggan ON pembelian.
    id_pelanggan = pelanggan.id_pelanggan 
    WHERE ((tanggal_pembelian BETWEEN '$tglm' AND '$tgls') AND status_pembayaran != 'pending')");

    while ($pecah = $ambil->fetch_assoc()) {
        $semuadata[] = $pecah;
    }
    // echo "<pre>";
    // print_r($semuadata);
    // echo "</pre>";
}
?>
<div class="container">
<div class="card shadow mb-4">

    <div class="card-header py-3">
        <h2 class="m-0 font-weight-bold text-primary">Laporan pembelian dari <?= $tglm ?> sampai <?= $tgls ?></h2>
    </div>
    </form>
    <div class="card-body">
        <form action="" method="POST" class="jangan">
            <div class="row mx-auto">
                
                <div class="col-md-4">
                <!-- tanggal mulai -->
                    <div class="form-group">
                        <label for="">Tanggal mulai</label>
                        <input type="date" class="form-control" name="tglm">
                    </div>
                </div>
                <!-- tanggal selesai -->
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="">Tanggal selesai</label>
                        <input type="date" class="form-control" name="tgls">
                    </div>
                </div>
                <!-- tombol lihat laporan -->
                <div class="col-md-1">
                    <label for="">&nbsp;</label> <br>
                    <button type="submit" class="btn btn-primary" name="cari">Lihat</button>
                </div>
                <!-- tombol cetak pdf -->
                <div class="col-md-1">
                    <label for="">&nbsp;</label> <br>
                    <a onclick="window.print()" class="btn btn-danger">Print</a>
                </div>
                <!-- tombol cetak excel -->
                <div class="col-md-2">
                    <label for="">&nbsp;</label> <br>
                    <a onclick="window.print()" class="btn btn-warning">Cetak Excel</a>
                </div>
            </div>
        </form>
        <div id="cetak " class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Pelanggan</th>
                        <th>Tanggal</th>
                        <th>Jumlah</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $no = 1;
                    foreach ($semuadata as $key => $data) :
                    ?>
                        <tr>
                            <td><?= $no ?></td>
                            <td><?= $data['nama'] ?></td>
                            <td><?= $data['tanggal_pembelian'] ?></td>
                            <td>Rp. <?= number_format($data['total_harga'])  ?></td>
                            <td><?= $data['status_pembayaran'] ?></td>
                        </tr>
                    <?php $no++;
                    endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</div>