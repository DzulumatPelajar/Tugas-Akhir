<?php
session_start();
foreach($_POST["id_produk"] as $id_produk){
    unset($_SESSION['keranjang'][$id_produk]);
}
// $id_produk = $_GET['id'];
// unset($_SESSION['keranjang'][$id_produk]);
echo"<script>alert('Produk berhasil dihapus dari keranjang')</script>";
echo"<script>location='keranjang.php'</script>";
